<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const SETTING_ID = 'jumpseat_registration_starting_balance';
    private const SETTING_KEY = 'jumpseat.registration_starting_balance';
    private const BALANCE_TABLE = 'jumpseat_starting_balances';

    public function up(): void
    {
        $now = now();

        if (Schema::hasTable('settings') && !DB::table('settings')->where('id', self::SETTING_ID)->exists()) {
            DB::table('settings')->insert([
                'id' => self::SETTING_ID,
                'offset' => ((int) (DB::table('settings')->max('offset') ?? 0)) + 100,
                'order' => ((int) (DB::table('settings')->max('order') ?? 0)) + 1,
                'key' => self::SETTING_KEY,
                'name' => 'New pilot registration starting balance',
                'value' => '0.00',
                'default' => '0.00',
                'group' => 'jumpseat',
                'type' => 'hidden',
                'options' => '',
                'description' => 'Amount credited once when a newly registered pilot confirms their email address. Blank or zero means no credit.',
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        if (!Schema::hasTable(self::BALANCE_TABLE)) {
            Schema::create(self::BALANCE_TABLE, function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('user_id')->unique();
                $table->decimal('amount', 12, 2)->default(0);
                $table->string('currency', 8);
                $table->unsignedBigInteger('transaction_id')->nullable();
                $table->timestamp('applied_at')->nullable();
                $table->timestamps();
                $table->index('transaction_id');
            });
        }
    }

    public function down(): void
    {
        // Keep the setting and audit table during uninstall so a reinstall
        // cannot accidentally erase the administrator's choice or credit log.
    }
};
