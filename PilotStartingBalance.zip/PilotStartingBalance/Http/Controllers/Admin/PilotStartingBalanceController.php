<?php

namespace Modules\PilotStartingBalance\Http\Controllers\Admin;

use App\Contracts\Controller;
use App\Models\Setting;
use App\Models\User;
use App\Services\FinanceService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Laracasts\Flash\Flash;
use Modules\PilotStartingBalance\Services\PilotStartingBalanceService;
use Modules\PilotStartingBalance\Support\UpdateChecker;

class PilotStartingBalanceController extends Controller
{
    public function index(): View
    {
        $pilots = User::query()
            ->with('journal')
            ->orderByDesc('created_at')
            ->orderBy('pilot_id')
            ->get()
            ->filter(function (User $pilot): bool {
                return !$pilot->journal || abs((float) $pilot->journal->getBalance()->getValue()) < 0.005;
            })
            ->values();

        $latestRelease = UpdateChecker::latestRelease();

        return view('pilotstartingbalance::admin.index', [
            'pilots' => $pilots,
            'currency' => setting('units.currency', 'USD'),
            'defaultStartingBalance' => max(0, (float) setting(PilotStartingBalanceService::SETTING_KEY, 0)),
            'currentVersion' => UpdateChecker::currentVersion(),
            'latestRelease' => $latestRelease,
            'updateAvailable' => UpdateChecker::isNewer($latestRelease),
            'repositoryUrl' => UpdateChecker::repositoryUrl(),
            'releaseUrl' => UpdateChecker::releaseUrl(),
        ]);
    }

    public function saveStartingBalance(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'default_starting_balance' => ['nullable', 'numeric', 'min:0', 'max:1000000'],
        ]);

        $setting = Setting::query()
            ->where('id', Setting::formatKey(PilotStartingBalanceService::SETTING_KEY))
            ->first();

        if (!$setting) {
            return back()->with('error', 'The Pilot Starting Balance setting is not available. Please reload the module before trying again.');
        }

        $value = number_format((float) ($data['default_starting_balance'] ?? 0), 2, '.', '');
        $setting->value = $value;
        $setting->type = 'hidden';
        $setting->save();

        $settingsCache = config('cache.keys.SETTINGS');
        if (is_array($settingsCache) && isset($settingsCache['key'])) {
            Cache::forget($settingsCache['key'].PilotStartingBalanceService::SETTING_KEY);
        }

        return back()->with('success', sprintf(
            'New pilot registration starting balance saved: %s %s. Blank or zero values result in zero credit.',
            setting('units.currency', 'USD'),
            number_format((float) $value, 2)
        ));
    }

    public function creditPilotBalance(Request $request, FinanceService $finance): RedirectResponse
    {
        $data = $request->validate([
            'user_ids' => ['required', 'array', 'min:1'],
            'user_ids.*' => ['required', 'integer', 'distinct', 'exists:users,id'],
            'amount' => ['required', 'numeric', 'gt:0', 'max:1000000'],
            'memo' => ['nullable', 'string', 'max:255'],
        ]);

        $pilotIds = array_map('intval', $data['user_ids']);
        $amount = number_format((float) $data['amount'], 2, '.', '');
        $memo = trim((string) ($data['memo'] ?? ''));
        $description = 'Pilot starting balance';
        if ($memo !== '') {
            $description .= ': '.$memo;
        }

        $credited = 0;
        $skipped = 0;

        DB::transaction(function () use ($pilotIds, $amount, $description, $finance, &$credited, &$skipped): void {
            foreach ($pilotIds as $pilotId) {
                $pilot = User::query()->whereKey($pilotId)->lockForUpdate()->first();
                if (!$pilot) {
                    $skipped++;
                    continue;
                }

                $currentBalance = $pilot->journal ? (float) $pilot->journal->getBalance()->getValue() : 0.0;
                if (abs($currentBalance) >= 0.005) {
                    $skipped++;
                    continue;
                }

                $journal = $pilot->journal ?: $pilot->initJournal(setting('units.currency', 'USD'));

                $finance->creditToJournal(
                    $journal,
                    Money::createFromAmount($amount),
                    $pilot,
                    $description,
                    'Pilot starting balance',
                    'pilot-starting-balance'
                );

                $credited++;
            }
        });

        if ($credited === 0) {
            return back()->with('error', 'No selected pilot had a zero balance at the time of submission. No credits were added.');
        }

        $message = sprintf(
            '%s %s credited to %d zero-balance pilot%s.',
            setting('units.currency', 'USD'),
            number_format((float) $amount, 2),
            $credited,
            $credited === 1 ? '' : 's'
        );

        if ($skipped > 0) {
            $message .= sprintf(' %d selected pilot%s skipped because the balance was no longer zero.', $skipped, $skipped === 1 ? '' : 's');
        }

        return back()->with('success', $message);
    }

    public function check(): RedirectResponse
    {
        UpdateChecker::forgetCachedRelease();
        Flash::success('GitHub release information refreshed.');

        return redirect()->route('admin.pilotstartingbalance.index');
    }
}
