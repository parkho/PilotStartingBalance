<?php

use Illuminate\Support\Facades\Route;

Route::get('/', 'PilotStartingBalanceController@index')->name('index');
Route::post('/default', 'PilotStartingBalanceController@saveStartingBalance')->name('default');
Route::post('/credit', 'PilotStartingBalanceController@creditPilotBalance')->name('credit');
Route::post('/check', 'PilotStartingBalanceController@check')->name('check');
