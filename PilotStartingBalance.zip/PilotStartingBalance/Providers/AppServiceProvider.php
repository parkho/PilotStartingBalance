<?php

namespace Modules\PilotStartingBalance\Providers;

use App\Services\ModuleService;
use Illuminate\Auth\Events\Verified;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Modules\PilotStartingBalance\Services\PilotStartingBalanceService;

class AppServiceProvider extends ServiceProvider
{
    public function boot(ModuleService $moduleSvc): void
    {
        $this->loadMigrationsFrom(__DIR__.'/../Database/migrations');
        $this->loadViewsFrom(__DIR__.'/../Resources/views', 'pilotstartingbalance');

        Event::listen(Verified::class, function (Verified $event): void {
            app(PilotStartingBalanceService::class)->apply($event->user);
        });

        $moduleSvc->addAdminLink('Pilot Starting Balance', '/admin/pilotstartingbalance', 'pe-7s-wallet');

        Route::group([
            'as' => 'admin.pilotstartingbalance.',
            'prefix' => 'admin/pilotstartingbalance',
            'middleware' => ['web', 'role:admin'],
            'namespace' => 'Modules\\PilotStartingBalance\\Http\\Controllers\\Admin',
        ], function (): void {
            $this->loadRoutesFrom(__DIR__.'/../Http/Routes/admin.php');
        });
    }
}
