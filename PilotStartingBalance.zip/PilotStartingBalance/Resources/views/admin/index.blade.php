@extends('admin.app')

@section('title', 'Pilot Starting Balance')

@section('actions')
  <li><a href="{{ $releaseUrl }}" target="_blank" rel="noopener">GitHub Releases</a></li>
@endsection

@section('content')
  @if($updateAvailable)
    <div class="alert alert-warning" role="alert">
      <strong>Pilot Starting Balance update available:</strong>
      version {{ $latestRelease['version'] }} is available (you are running
      {{ $currentVersion }}).
      <a href="{{ $latestRelease['url'] }}" target="_blank" rel="noopener">Download the update from GitHub</a>,
      then replace the module through <strong>Admin -> Modules -> Add New</strong>.
    </div>
  @elseif($latestRelease)
    <div class="alert alert-success" role="status">
      Pilot Starting Balance is up to date at version {{ $currentVersion }}.
    </div>
  @else
    <div class="alert alert-info" role="status">
      GitHub could not be reached for an update check right now. The module is
      still operating normally; try <strong>Check GitHub now</strong> again later.
    </div>
  @endif

  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif
  @if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
  @endif
  @if($errors->any())
    <div class="alert alert-danger">
      @foreach($errors->all() as $error)
        <div>{{ $error }}</div>
      @endforeach
    </div>
  @endif

  <div class="card border-blue-bottom">
    <div class="header"><h4 class="title">Module status</h4></div>
    <div class="content">
      <dl class="dl-horizontal">
        <dt>Installed version</dt>
        <dd>{{ $currentVersion }}</dd>
        <dt>Release source</dt>
        <dd><a href="{{ $repositoryUrl }}" target="_blank" rel="noopener">{{ $repositoryUrl }}</a></dd>
        <dt>Verified-pilot credit</dt>
        <dd>Applied once after email confirmation</dd>
      </dl>

      <form method="post" action="{{ route('admin.pilotstartingbalance.check') }}">
        @csrf
        <button class="btn btn-primary" type="submit">Check GitHub now</button>
      </form>

      <p class="text-muted" style="margin-top: 15px;">
        Release checks are cached for six hours. This module does not self-update:
        download a release from GitHub and install it through the phpVMS module
        manager so the administrator remains in control.
      </p>
    </div>
  </div>

  <div class="card border-blue-bottom" style="margin-top:20px">
    <div class="header"><h4 class="title">New pilot default balance</h4></div>
    <div class="content">
      <div class="alert alert-info">
        Set the amount to be credited once when a newly registered pilot confirms their email. Blank or zero means zero credit. Changing this value affects future email confirmations only; existing pilots are not changed.
      </div>

      <form method="post" action="{{ route('admin.pilotstartingbalance.default') }}" class="row">
        @csrf
        <div class="col-md-4">
          <label for="default-starting-balance">Starting balance ({{ $currency }})</label>
          <input id="default-starting-balance" class="form-control" type="number" name="default_starting_balance" value="{{ old('default_starting_balance', $defaultStartingBalance > 0 ? number_format($defaultStartingBalance, 2, '.', '') : '') }}" min="0" max="1000000" step="0.01" placeholder="0.00">
          <p class="help-block">A verified pilot receives this once in their phpVMS journal.</p>
        </div>
        <div class="col-md-8" style="padding-top:25px">
          <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save default balance</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card border-blue-bottom" style="margin-top:20px">
    <div class="header"><h4 class="title">Manual one-off pilot credit</h4></div>
    <div class="content">
      <div class="alert alert-info">
        Apply the same one-off credit to multiple pilots. Only pilots with a current balance of zero are listed. Each submission creates a separate auditable credit in each selected pilot's phpVMS journal.
      </div>

      <form method="post" action="{{ route('admin.pilotstartingbalance.credit') }}" class="row">
        @csrf
        <div class="col-md-6">
          <label for="pilot-balance-users">Zero-balance pilots</label>
          <select id="pilot-balance-users" name="user_ids[]" class="form-control" multiple size="8" required>
            @forelse($pilots as $pilot)
              @php
                $currentBalance = $pilot->journal ? $pilot->journal->getBalance()->getValue() : 0;
              @endphp
              <option value="{{ $pilot->id }}" @selected(in_array((string) $pilot->id, array_map('strval', (array) old('user_ids', [])), true))>
                #{{ $pilot->pilot_id }} &mdash; {{ $pilot->callsign ?: 'No callsign' }} &mdash; {{ $pilot->name }} ({{ $currency }} {{ number_format($currentBalance, 2) }})
              </option>
            @empty
              <option value="" disabled>No zero-balance pilots available</option>
            @endforelse
          </select>
          <p class="help-block">Hold Ctrl/Cmd while clicking to select multiple pilots. The current balance is shown in parentheses.</p>
        </div>
        <div class="col-md-3">
          <label for="pilot-balance-amount">Amount ({{ $currency }})</label>
          <input id="pilot-balance-amount" class="form-control" type="number" name="amount" value="{{ old('amount') }}" min="0.01" max="1000000" step="0.01" required>
        </div>
        <div class="col-md-3">
          <label for="pilot-balance-memo">Memo (optional)</label>
          <input id="pilot-balance-memo" class="form-control" type="text" name="memo" value="{{ old('memo') }}" maxlength="255" placeholder="New pilot allowance">
        </div>
        <div class="col-md-12" style="margin-top:15px">
          <button type="submit" class="btn btn-primary" onclick="return confirm('Credit this amount to all selected zero-balance pilots?');"><i class="fa fa-plus-circle"></i> Add balance to selected pilots</button>
        </div>
      </form>
    </div>
  </div>
@endsection
