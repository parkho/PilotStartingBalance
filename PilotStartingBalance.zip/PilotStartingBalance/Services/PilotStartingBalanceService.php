<?php

namespace Modules\PilotStartingBalance\Services;

use App\Models\User;
use App\Services\FinanceService;
use App\Support\Money;
use Illuminate\Support\Facades\DB;

class PilotStartingBalanceService
{
    /**
     * These identifiers are retained for compatibility with the original
     * AEV/Jumpseat implementation of this feature.
     */
    public const SETTING_KEY = 'jumpseat.registration_starting_balance';

    private const TRANSACTION_GROUP = 'Pilot registration starting balance';
    private const BALANCE_TABLE = 'jumpseat_starting_balances';

    private $finance;

    public function __construct(FinanceService $finance)
    {
        $this->finance = $finance;
    }

    public function apply(User $user): void
    {
        DB::transaction(function () use ($user): void {
            $pilot = User::query()->whereKey($user->id)->lockForUpdate()->first();
            if (!$pilot) {
                return;
            }

            if (DB::table(self::BALANCE_TABLE)->where('user_id', $pilot->id)->exists()) {
                return;
            }

            $currency = setting('units.currency', 'USD');
            $amount = max(0, round((float) setting(self::SETTING_KEY, 0), 2));
            $transactionId = null;

            if ($amount > 0) {
                $journal = $pilot->journal ?: $pilot->initJournal($currency);
                $transaction = $this->finance->creditToJournal(
                    $journal,
                    Money::createFromAmount($amount),
                    $pilot,
                    'Pilot registration starting balance',
                    self::TRANSACTION_GROUP,
                    'pilot-registration-starting-balance'
                );
                $transactionId = $transaction->id ?? null;
            }

            DB::table(self::BALANCE_TABLE)->insert([
                'user_id' => $pilot->id,
                'amount' => number_format($amount, 2, '.', ''),
                'currency' => $currency,
                'transaction_id' => $transactionId,
                'applied_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });
    }
}
