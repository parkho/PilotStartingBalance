<?php

namespace Modules\PilotStartingBalance\Support;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Throwable;

final class UpdateChecker
{
    private const CURRENT_VERSION = '1.0.0';
    private const REPOSITORY = 'parkho/PilotStartingBalance';
    private const CACHE_KEY = 'pilotstartingbalance.github.latest_release';
    private const CACHE_MINUTES = 360;

    public static function currentVersion(): string
    {
        return self::CURRENT_VERSION;
    }

    public static function repositoryUrl(): string
    {
        return 'https://github.com/'.self::REPOSITORY;
    }

    public static function releaseUrl(): string
    {
        return self::repositoryUrl().'/releases/latest';
    }

    /**
     * Return the latest valid GitHub release, cached for six hours.
     * A failed check never affects registration or administrator credits.
     */
    public static function latestRelease(): ?array
    {
        try {
            return Cache::remember(self::CACHE_KEY, now()->addMinutes(self::CACHE_MINUTES), function (): ?array {
                return self::fetchLatestRelease();
            });
        } catch (Throwable $e) {
            return self::fetchLatestRelease();
        }
    }

    public static function isNewer(?array $release): bool
    {
        return $release !== null
            && version_compare($release['version'], self::CURRENT_VERSION, '>');
    }

    public static function forgetCachedRelease(): void
    {
        try {
            Cache::forget(self::CACHE_KEY);
        } catch (Throwable $e) {
            // A cache failure must not prevent administrators from using the
            // balance settings or the manual credit form.
        }
    }

    private static function fetchLatestRelease(): ?array
    {
        try {
            $response = Http::withHeaders([
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'PilotStartingBalance/'.self::CURRENT_VERSION,
            ])->timeout(5)->get(
                'https://api.github.com/repos/'.self::REPOSITORY.'/releases/latest'
            );

            if (!$response->successful()) {
                return null;
            }

            $tag = trim((string) $response->json('tag_name'));
            $version = ltrim($tag, 'vV');

            if (!preg_match('/^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$/', $version)) {
                return null;
            }

            return [
                'version' => $version,
                'tag' => $tag,
                'name' => trim((string) $response->json('name')) ?: $tag,
                'url' => trim((string) $response->json('html_url')) ?: self::releaseUrl(),
                'published_at' => trim((string) $response->json('published_at')),
            ];
        } catch (Throwable $e) {
            return null;
        }
    }
}
